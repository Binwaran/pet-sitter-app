import { updateAverageRating } from '@/utils/updateAverageRating'

// ใส่ sitter_id ที่ต้องการอัปเดต
await updateAverageRating('914e1f5b-468b-45dd-b92b-9c6ebdba57db')
await updateAverageRating('9f9861f2-1c4b-4e6b-bbf0-ad0110fefc21')
await updateAverageRating('52975b6a-a3e4-4e52-aa94-ccebfaac3470')
await updateAverageRating('7af0b27c-f5d4-4365-8adf-30b5913504b6')
await updateAverageRating('c8dce7ab-d8cc-40c6-b9c2-ace089607314')
